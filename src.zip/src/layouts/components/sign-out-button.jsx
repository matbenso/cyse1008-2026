import { useCallback } from 'react';

import Button from '@mui/material/Button';

import { useRouter } from 'src/routes/hooks';

import { toast } from 'src/components/snackbar';

import { useAuthContext } from 'src/auth/hooks';
import { signOut as firebaseSignOut } from 'src/auth/context/firebase/action';

// ----------------------------------------------------------------------

const signOut = firebaseSignOut;

// ----------------------------------------------------------------------

export function SignOutButton({
  onClose,
  fullWidth = true,
  variant = 'soft',
  size = 'large',
  color = 'error',
  children = 'Logout',
  ...other
}) {
  const router = useRouter();

  const { checkUserSession } = useAuthContext();

  const handleLogout = useCallback(async () => {
    try {
      await signOut();
      await checkUserSession?.();

      onClose?.();
      router.refresh();
    } catch (error) {
      console.error(error);
      toast.error('Unable to logout!');
    }
  }, [checkUserSession, onClose, router]);

  return (
    <Button
      fullWidth={fullWidth}
      variant={variant}
      size={size}
      color={color}
      onClick={handleLogout}
      {...other}
    >
      {children}
    </Button>
  );
}
